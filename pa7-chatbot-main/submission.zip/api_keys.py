# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY="cc270a1cea9a48da29b40af32a7677fa3ec0c8cd3aa993b709b000b3bb942abd"